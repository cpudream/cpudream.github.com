---
title: "《第一行代码》"
categories: Android 
tags: 《第一行代码》
date: 2016-08-16
---

<font color="red" size = "4" >（本页长期更新）</font>买这本书是因为经常见网上的大牛推荐，这本书作者是郭林大神，他的博客地址是[http://blog.csdn.net/guolin_blog](http://blog.csdn.net/guolin_blog)。我2016年8月16号收到这本书现在看了多一半（8月28号更新），这本书感觉非常非常基础，当然读这本书要有Java基础了。个人感觉不适合有基础的人看，不过也可以拿来看看把容易忽略和不会的总结出来。下面是看这本书时写的一些<!-- more -->文章笔记方便查找。
![](http://of0xqj5p6.bkt.clouddn.com/2016/0816firstcode.jpg)




### 笔记索引

- [**第一章**：开始启程，你的第一行Android代码](http://blog.liuyufeng.tech/post/2016-08-17-start-first-code.html)
- [**第二章**：先从看得到的入手，探究活动](http://blog.liuyufeng.tech/post/2016-09-02-android-activity-studio.html)
- [**第三章**：软件也要拼脸蛋，UI开发的点点滴滴](http://blog.liuyufeng.tech/post/2016-08-31-android-ui.html)
- [**第四章**：手机平板要兼顾，探究碎片](http://blog.liuyufeng.tech/post/2016-09-05-android-fragment-studio.html)
- [**第五章**：全局大喇叭，详解广播机制](http://blog.liuyufeng.tech/post/2016-09-07-android-broadcast-studio.html)
- [**第六章**：数据存储全方案，详解持久化技术](http://blog.liuyufeng.tech/post/2016-08-26-android-database.html)
- [**第七章**：跨程序共享数据，探究内容提供器](http://blog.liuyufeng.tech/post/2016-09-18-android-contentprovider.html)
- [**第九章**：后台默默的劳动者，探究服务](http://blog.liuyufeng.tech/post/2016-09-25-android-service.html)


