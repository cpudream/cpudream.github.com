---
title: "计算机专业词汇"
categories: Computer 
tags: EngLish
date: 2016-09-02
---

<font color="red">(本页持续更新)</font>英文对于初级程序员来说不怎么重要但是对于一些经常用到的专业词汇还是要记住的
1. Graphical(绘成图画似的，绘画的)  
2. Patterns(模式) 
3. Filter(过滤器) 
4. MIME(Multipurpose Internet Mail Extensions)多用途互联网邮件扩展。是一种互联网标准  
5. Qualifiers(限定符)   
6. priority优先  
7. Retrieve(查询) 
8. SQL(Structured Query Language)
9. reverse颠倒，相反
10. indices 
11. parentheses括号
12. generateParenthesis生成括号
13. Invalid 
14. is the given date valid?
15. a date that represents the next day after this day
16. validate验证确认， validate that p is a valid index
17. Annotation注解
18. Scope作用域
19. Subscribe订阅
20. attach订阅
21. detach分离
22. decorator 装饰模式
23. hybrid 混合
24. interpolator插入器
25. Evaluator类型估值器
26. reverse相反
27. INFINITE无限的
28. snippet 小片
