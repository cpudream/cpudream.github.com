---
title: "Hello World"
categories: 当然我在扯淡
tags: 开博客啦
date: 2016-07-22
---

从大二起，就开始接触CSDN和博客园了。主要是刷题记录和一些琐碎。大三下学期感觉 csdn 不能满足需求主要是广告太多，在一次偶然的机会得知GitHub上可以搭博客，就想开设一个独立的博客，但是苦于肚子里没有什么干货，就只是当作一个念头偶尔想想。文章还是放在 csdn 上面。现在已经大四了，学习的东西虽然也没有多少，但是总算有了一点点的积累，加上自己大三一年对学习和生活又有了很大的感悟，就又一次燃起了开博客的念头。因为是计算机出身，所以以后博客肯定以计算机知识为主，个人的零零碎碎为辅。由于我的爱好比较多，以后文章<!--more-->可能会涉及很多方面。 
我是一个简单的人，也没有所谓的壮志凌云，就是希望能通过自己的努力，一步步改善现在的状况，去实现一些自己认为值得的梦想。不管怎么说，这只是一个我记录我学习、生活的博客，如果以后回忆起大学时光，这个博客能起到一丝作用，这个博客的作用就达到了：）

###  博客样式代码总结


<span id="inline-toc">1.</span>



<div class="note default"><p>default</p></div>



<div class="note primary"><p>primary</p></div>



<div class="note success"><p>success</p></div>

<div class="note info"><p>info</p></div>



<div class="note warning"><p>warning</p></div>



<div class="note danger"><p>danger</p></div>



<div class="note danger no-icon"><p>danger no-icon</p></div>



{% label default@default %}     、、、、、、、、、


{% label primary@primary %}    、、、、、、、、、


{% label success@success %}    、、、、、、、、、



{% label info@info %}   、、、、、、、、、



{% label warning@warning %}  、、、、、、、、、



{% label danger@danger %}  、、、、、、、、、

{% btn https://www.baidu.com, 点击下载百度, download fa-lg fa-fw %}
、、、、、、


{% tabs 选项卡, 2 %}
<!-- tab -->
**这是选项卡 1** 呵呵哈哈哈哈哈哈哈哈呵呵哈哈哈哈哈哈哈哈呵呵哈哈哈哈哈哈哈哈呵呵哈哈哈哈哈哈哈哈呵呵哈哈哈哈哈哈哈哈呵呵哈哈哈哈哈哈哈哈……
<!-- endtab -->
<!-- tab -->
**这是选项卡 2**
<!-- endtab -->
<!-- tab -->
**这是选项卡 3** 哇，你找到我了！φ(≧ω≦*)♪～
<!-- endtab -->
{% endtabs %}







<blockquote class="question">内容</blockquote>


{% cq %}
人生乃是一面镜子，
从镜子里认识自己，
我要称之为头等大事，
也只是我们追求的目的！
{% endcq %}	



