---
title: "Android屏幕适配教程"
categories: Android 
tags: 屏幕适配
date: 2016-09-06
---
<font color="red">(文章有待更新)</font>屏幕适配有个概念还是要知道的限定符（Qualifiers）
,但是这个概念范围比较广，所以出来了最小宽度限定符（Smallest-width Qualifier）最小限定符是在android3.2引入的。比如layout-sw600dp,就是屏幕宽度大于600dp的加载这个布局。现列出android中常用的限定符。
![](http://of0xqj5p6.bkt.clouddn.com/2016/0906androidqualifiers.jpg)
<!--more-->
