---
title: "Android群英传"
categories: Android 
tags: 《Android群英传》
date: 2016-09-24
---

<font color = "red" size = 4>(本页长期更新)</font>终于把郭林大神的第一行代码消化的差不多了，但是Android手机多媒体那一章节还没有看，就看了看徐医生的《Android群英传》，他的博客地址是[http://blog.csdn.net/eclipsexys](http://blog.csdn.net/eclipsexys)。这本书给我的第一映像是，适合进阶因为有些东西我看起来比较吃力，没有第一行代码看起来快。讲的全是我不熟悉的比如动画，绘图机制，5.x特性，控件原理，不过这本书没有第一行代码厚。浏览了一下大致的几章节给我的感觉是此书看一遍不行呀。好苦逼的样子。<!--more-->

### 笔记索引

- [**第一章**：Android体系与系统架构](http://blog.liuyufeng.tech/post/2016-08-17-start-first-code.html)
- [**第三章**：Android控件架构与自定义控件详解](http://blog.liuyufeng.tech/post/2016-11-08-android-custom.html)
