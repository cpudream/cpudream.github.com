---
title: 英文提问技巧
categories: English 
tags: skill
date: 2016-11-19
---

<font color = "red">有待更新</font>英语这个玩意重要性不得不说，但是对于英语文盲来说，有时真需要在外国论坛里问一些东西，现总结常用的用英语提问技巧，，我想到的问题未免就是是什么，为什么，怎么做，在哪里等，以下是几种句型，把固定句型记住或许会有更好的作用。<!-- more -->
### How
How语句翻译为如何，常用的提问有 How to + 动词原型 >> How do I +动词 + when
1. <font color="#42b983">How to handle</font> screen orientation change <font color="#42b983">when</font> progress dialog and background thread active?
    (当进度对话框和后台线程活动时如何处理屏幕方向更改？)
2. <font color="#42b983">How can I</font> connect to Android with ADB over TCP?
    (如何使用ADB通过TCP连接到Android？)
3. <font color="#42b983">How to</font> send an object from one Android Activity to another using Intents?
    (如何使用Intents将对象从一个Android活动发送到另一个？)
4. <font color="#42b983">How do I</font> discover memory usage of my application in Android?
    (如何在Android中发现我的应用程序的内存使用情况？)
5. <font color="#42b983">How can I</font> open a URL in Android's web browser from my application?

### what
What总体来说是什么的意思
1. <font color="#42b983">what is the difference between</font> "dp" <font color="#42b983">and</font> "sp" in Android?
    (Android中“dp”和“sp”之间有什么区别？)
2. What is the shortcut to Auto import all in Android Studio?
    (AndroidStudio中自动导包的快捷键是什么)
3. Is there a way to run Python on Android?
   （有没有办法在Android上运行Python？）
4. What is 'Context' on Android?
5. Difference between a View's Padding and Margin

### Why
为什么
1. Why is the Android emulator so slow? How can we speed up the Android emulator?

### where
1. Where to place Assets folder in Android Studio
   （在Android Studio中将资源文件夹放置在何处）
   
### 乱七八

That is all I can think of at the moment. I might update my answer later.
Sorry for English mistakes, it is not my native language
Why does the Chinese government ban some products which are not relevant to politics at all?
invalid
what shoud I do？
I used the methods 
Please help me with this problem,
I try to do it about 3 days, but no result yet.
But I'll admit, I still get a good laugh whenever I think back about that time.
I think pics can explain it’s  true below 
Hi, Thanks for this awesome library.
tutorial
I want to avoid the repeated values and the -0 values in Y-Axis, avoiding the image situation.

I have these ideas to solve this, but any solution:

value duplicating when zooming in

How can I avoid the repeated values in Y-Axis?

Within the App I have an issue where
I need to read more carefully the issue  because I don't get the problem.

 raw value

This chapter covers the topic of setting data to various kinds of Charts.
